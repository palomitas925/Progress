-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 10.200.10.213
-- Tiempo de generación: 03-12-2025 a las 18:40:12
-- Versión del servidor: 10.11.13-MariaDB-deb11-log
-- Versión de PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `popcode`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `campos`
--

CREATE TABLE `campos` (
  `id` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `tipo` varchar(50) DEFAULT 'text',
  `orden` int(11) DEFAULT 0,
  `requerido` tinyint(1) DEFAULT 0,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `campos`
--

INSERT INTO `campos` (`id`, `id_categoria`, `nombre`, `tipo`, `orden`, `requerido`, `meta`, `fecha_creacion`) VALUES
(96, 30, 'Codigo', 'text', 0, 0, NULL, '2025-11-13 02:43:04'),
(97, 30, 'Cantidad', 'text', 1, 0, NULL, '2025-11-13 02:43:04'),
(98, 30, 'Descripcion', 'text', 2, 0, NULL, '2025-11-13 02:43:04'),
(99, 31, 'CLV', 'text', 0, 0, NULL, '2025-11-18 15:51:25'),
(100, 31, 'Cantidad', 'text', 1, 0, NULL, '2025-11-18 15:51:25'),
(101, 31, 'Linea', 'text', 2, 0, NULL, '2025-11-18 15:51:25'),
(102, 31, 'Area', 'text', 3, 0, NULL, '2025-11-18 15:51:25'),
(103, 31, 'Departamento. Nombre/Posicion', 'text', 4, 0, NULL, '2025-11-18 15:51:25'),
(104, 31, 'Ubicacion', 'text', 5, 0, NULL, '2025-11-18 15:51:25'),
(105, 31, 'Estado', 'text', 6, 0, NULL, '2025-11-18 15:51:25'),
(106, 31, 'Hostname', 'text', 7, 0, NULL, '2025-11-18 15:51:25'),
(107, 31, 'Tipo_Computadora', 'text', 8, 0, NULL, '2025-11-18 15:51:25'),
(108, 31, 'Marca', 'text', 9, 0, NULL, '2025-11-18 15:51:25'),
(109, 31, 'Modelo', 'text', 10, 0, NULL, '2025-11-18 15:51:25'),
(110, 31, 'Etiqueta', 'text', 11, 0, NULL, '2025-11-18 15:51:25'),
(111, 31, 'Express Code', 'text', 12, 0, NULL, '2025-11-18 15:51:25'),
(112, 31, 'Procesador', 'text', 13, 0, NULL, '2025-11-18 15:51:25'),
(113, 31, 'Generacion', 'text', 14, 0, NULL, '2025-11-18 15:51:25'),
(114, 31, 'Nucleos', 'text', 15, 0, NULL, '2025-11-18 15:51:25'),
(115, 31, 'Memoria', 'text', 16, 0, NULL, '2025-11-18 15:51:25'),
(116, 31, 'Tipo_disco', 'text', 17, 0, NULL, '2025-11-18 15:51:25'),
(117, 31, 'Almacenamiento', 'text', 18, 0, NULL, '2025-11-18 15:51:25'),
(118, 31, 'Sistema Operativo', 'text', 19, 0, NULL, '2025-11-18 15:51:25'),
(119, 31, 'Cargador', 'text', 20, 0, NULL, '2025-11-18 15:51:25'),
(120, 31, 'IPv4/v6', 'text', 21, 0, NULL, '2025-11-18 15:51:25'),
(121, 31, 'Observaciones', 'text', 22, 0, NULL, '2025-11-18 15:51:25'),
(122, 32, 'Numero de uniforme', 'text', 0, 0, NULL, '2025-11-21 20:31:08'),
(123, 32, 'Cantidad', 'text', 1, 0, NULL, '2025-11-21 20:31:08'),
(124, 32, 'Talla', 'text', 2, 0, NULL, '2025-11-21 20:31:08'),
(125, 32, 'Observaciones', 'text', 3, 0, NULL, '2025-11-21 20:31:08'),
(126, 33, 'Number', 'text', 0, 0, NULL, '2025-12-03 16:52:56'),
(127, 33, 'Cantidad', 'text', 1, 0, NULL, '2025-12-03 16:52:56'),
(128, 33, 'Talla', 'text', 2, 0, NULL, '2025-12-03 16:52:56'),
(129, 33, 'Estado', 'text', 3, 0, NULL, '2025-12-03 16:52:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `inventario_id` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `campos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[]' CHECK (json_valid(`campos`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `inventario_id`, `nombre`, `campos`, `fecha_creacion`) VALUES
(30, 22, 'Infraestructura prueba', '[]', '2025-11-13 02:43:04'),
(31, 22, 'Equipos de computo', '[]', '2025-11-18 15:51:25'),
(32, 23, 'Uniformes', '[]', '2025-11-21 20:31:08'),
(33, 23, 'Cofias', '[]', '2025-12-03 16:52:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial`
--

CREATE TABLE `historial` (
  `id` int(11) NOT NULL,
  `fecha_operacion` datetime NOT NULL DEFAULT current_timestamp(),
  `operacion` enum('retiro','devolucion') NOT NULL,
  `codigo_retiro` int(11) DEFAULT NULL,
  `fecha_retiro` datetime DEFAULT NULL,
  `fecha_devolucion` datetime DEFAULT NULL,
  `no_colaborador` varchar(255) DEFAULT NULL,
  `inventario` varchar(255) DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `articulo_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `historial`
--

INSERT INTO `historial` (`id`, `fecha_operacion`, `operacion`, `codigo_retiro`, `fecha_retiro`, `fecha_devolucion`, `no_colaborador`, `inventario`, `categoria`, `articulo_id`, `cantidad`, `observaciones`) VALUES
(17, '2025-11-13 03:43:40', 'retiro', 17, '2025-11-13 03:43:40', NULL, '581', 'Inventario Tecnologias de la Informacion', 'Infra', 14, 1, ''),
(18, '2025-11-13 03:43:40', 'retiro', 18, '2025-11-13 03:43:40', NULL, '581', 'Inventario Tecnologias de la Informacion', 'Infra', 14, 1, ''),
(19, '2025-11-13 03:44:34', 'devolucion', 18, '2025-11-13 03:43:40', '2025-11-13 08:44:00', '581', 'Inventario Tecnologias de la Informacion', 'Infra', 14, 1, ''),
(20, '2025-11-13 03:44:42', 'devolucion', 17, '2025-11-13 03:43:40', '2025-11-13 08:44:00', '581', 'Inventario Tecnologias de la Informacion', 'Infra', 14, 1, ''),
(21, '2025-11-13 04:28:13', 'retiro', 21, '2025-11-13 04:28:13', NULL, '581', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 10, 'Las impresoras se entregaron en tiempo y en perfecto estado'),
(22, '2025-11-13 04:29:30', 'devolucion', 21, '2025-11-13 04:28:13', '2025-11-13 09:28:00', '581', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 10, 'Solo se entregaron 9 unidades de las 10 que se prestaron'),
(23, '2025-11-15 02:14:47', 'retiro', 23, '2025-11-15 02:14:47', NULL, '580', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 50, ''),
(24, '2025-11-15 02:16:47', 'devolucion', 23, '2025-11-15 02:14:47', '2025-11-15 07:16:00', '580', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 49, 'Las unidades se entregaron en perfectas condiciones'),
(25, '2025-11-15 02:17:12', 'devolucion', 23, '2025-11-15 02:14:47', '2025-11-15 07:17:00', '580', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 1, ''),
(26, '2025-11-15 02:53:08', 'retiro', 26, '2025-11-15 02:53:08', NULL, '581', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 50, 'Los productos que se entregaron fueron entregados en perfectas condiciones'),
(27, '2025-11-17 06:20:39', 'devolucion', 26, '2025-11-15 02:53:08', '2025-11-17 11:20:00', '581', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 50, ''),
(28, '2025-11-18 16:38:49', 'retiro', 28, '2025-11-18 16:38:49', NULL, '850', 'Inventario Tecnologias de la Informacion', 'Infra', 17, 10, ''),
(29, '2025-11-18 16:40:54', 'retiro', 29, '2025-11-18 16:40:54', NULL, '850', 'Inventario Tecnologias de la Informacion', 'Infra', 17, 1, ''),
(30, '2025-11-18 18:10:20', 'devolucion', 26, '2025-11-15 02:53:08', '2025-11-18 23:08:00', '581', 'Inventario Tecnologias de la Informacion', 'Infra', 16, 50, ''),
(31, '2025-11-19 23:15:51', 'retiro', 31, '2025-11-19 23:15:51', NULL, '850', 'Inventario Tecnologias de la Informacion', 'Equipos de computo', 19, 1, 'El equipo se entrego en perfectas condiciones'),
(32, '2025-11-19 23:16:28', 'devolucion', 31, '2025-11-19 23:15:51', '2025-11-20 04:14:00', '850', 'Inventario Tecnologias de la Informacion', 'Equipos de computo', 19, 1, ''),
(33, '2025-11-19 23:16:48', 'retiro', 33, '2025-11-19 23:16:48', NULL, '850', 'Inventario Tecnologias de la Informacion', 'Equipos de computo', 19, 2, ''),
(34, '2025-11-19 23:17:15', 'devolucion', 33, '2025-11-19 23:16:48', '2025-11-20 04:15:00', '850', 'Inventario Tecnologias de la Informacion', 'Equipos de computo', 19, 2, ''),
(35, '2025-12-03 17:34:02', 'retiro', 35, '2025-12-03 17:34:02', NULL, '850', 'Inventario Tecnologias de la Informacion', 'Equipos de computo', 53, 2, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `identificador` varchar(100) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `inventarios`
--

INSERT INTO `inventarios` (`id`, `nombre`, `identificador`, `fecha_creacion`) VALUES
(22, 'Inventario Tecnologias de la Informacion', 'Codigo', '2025-11-13 02:43:04'),
(23, 'Inventario TH', 'Numero de uniforme', '2025-11-21 20:31:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_areas`
--

CREATE TABLE `inventario_areas` (
  `id` int(11) NOT NULL,
  `id_inventario` int(11) NOT NULL,
  `area_code` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_categories_assoc`
--

CREATE TABLE `inventario_categories_assoc` (
  `id` int(11) NOT NULL,
  `id_inventario` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_escanear`
--

CREATE TABLE `productos_escanear` (
  `codigo_barras` varchar(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `productos_escanear`
--

INSERT INTO `productos_escanear` (`codigo_barras`, `descripcion`, `imagen`, `fecha`) VALUES
('1234567891011', 'Slimpop', '6914e936d4175_1743392586527.jpg', '2025-10-31'),
('2537492563524', 'Prueba2', 'prod_2537492563524_1761935744.png', '2025-10-31'),
('45245654678467867', 'Borrar', '69151786dbe35_Fondo de pantalla para computador ilustracion gato rosa y marron (2).png', '2025-10-30'),
('5473648475638', 'Prueba del supervisor', 'prod_5473648475638_1763495168.png', '2025-11-18'),
('7500463970917', 'Slimpop Sweet & Salty 125g', '1761763539_Sweet.png', '2025-10-23'),
('7503036785103', 'Slimpop Netflix Sabor Salsas Negras 125g', 'prod_7503036785103_1761251383.jpg', '2025-10-23'),
('7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '691c92d7c8822_chiles.png', '2025-10-23'),
('7503036787158', 'Netflix Mantequilla', '6903b589c589e_prueba 3.jpg', '2025-10-30'),
('7503036787165', 'Cheddar & Caramel Mix', '6914e910a1d85_1740972324048.jpg', '2025-11-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE `registros` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `datos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`datos`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `texto_busqueda` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `registros`
--

INSERT INTO `registros` (`id`, `categoria_id`, `datos`, `fecha_creacion`, `fecha_modificacion`, `texto_busqueda`) VALUES
(16, 30, '{\"Cantidad\":\"100\",\"Codigo\":\"23213921093\",\"Descripcion\":\"Impresora HP DeskJet 5043\"}', '2025-11-13 03:27:39', '2025-11-18 17:10:20', NULL),
(17, 30, '{\"Cantidad\":\"4 - 11\",\"Codigo\":\"0210\",\"Descripcion\":\"Laptop Dell Inspiron \"}', '2025-11-18 15:37:45', '2025-11-18 15:40:54', NULL),
(18, 30, '{\"Cantidad\":\"1\",\"Codigo\":\"117\",\"Descripcion\":\"Laptop Asus ROG Strix\"}', '2025-11-18 15:46:22', '2025-12-02 16:22:39', NULL),
(19, 31, '{\"Cantidad\":\"15\",\"CLV\":\"12\",\"Linea\":\"PFG\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI OMAR\",\"Ubicacion\":\"PRADERA\",\"Estado\":\"SEMINUEVO\",\"Hostname\":\"SUPER\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"Dell\",\"Modelo\":\"Cisco\",\"Etiqueta\":\"CXX22\",\"Express Code\":\"CXX22\",\"Procesador\":\"INTEL \",\"Generacion\":\"10\",\"Nucleos\":\"8\",\"Memoria\":\"16 \",\"Tipo_disco\":\"NVME \",\"Almacenamiento\":\"256GB\",\"Sistema Operativo\":\"WINDOWS\",\"Cargador\":\"SI \",\"IPv4\\/v6\":\"192.168.1.2\",\"Observaciones\":\"COMO NUEVO \"}', '2025-11-18 16:03:11', '2025-11-19 22:17:15', NULL),
(21, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-11-21 17:31:28', '2025-11-21 20:28:33', NULL),
(22, 32, '{\"Cantidad\":\"5\",\"Numero de uniforme\":\"1\",\"Talla\":\"M\",\"Observaciones\":\"COMO NUEVO \"}', '2025-11-21 20:31:29', '2025-11-21 20:31:29', NULL),
(23, 32, '{\"Cantidad\":\"4\",\"Numero de uniforme\":\"1\",\"Talla\":\"M\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:55:31', '2025-12-02 16:55:31', NULL),
(24, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:18', '2025-12-02 16:56:18', NULL),
(25, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:24', '2025-12-02 16:56:24', NULL),
(26, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:31', '2025-12-02 16:56:31', NULL),
(27, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:36', '2025-12-02 16:56:36', NULL),
(28, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:42', '2025-12-02 16:56:42', NULL),
(29, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:47', '2025-12-02 16:56:47', NULL),
(30, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:52', '2025-12-02 16:56:52', NULL),
(31, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:56:58', '2025-12-02 16:56:58', NULL),
(32, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:03', '2025-12-02 16:57:03', NULL),
(33, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:09', '2025-12-02 16:57:09', NULL),
(34, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:14', '2025-12-02 16:57:14', NULL),
(35, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:20', '2025-12-02 16:57:20', NULL),
(36, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:25', '2025-12-02 16:57:25', NULL),
(37, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:30', '2025-12-02 16:57:30', NULL),
(38, 30, '{\"Cantidad\":\"15\",\"Codigo\":\"0211\",\"Descripcion\":\"Laptop Dell Inspiron 6\"}', '2025-12-02 16:57:38', '2025-12-02 16:57:38', NULL),
(39, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:04', '2025-12-02 16:58:04', NULL),
(40, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:10', '2025-12-02 16:58:10', NULL),
(41, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:18', '2025-12-02 16:58:18', NULL),
(42, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:22', '2025-12-02 16:58:22', NULL),
(43, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:27', '2025-12-02 16:58:27', NULL),
(44, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:33', '2025-12-02 16:58:33', NULL),
(45, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:39', '2025-12-02 16:58:39', NULL),
(46, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:44', '2025-12-02 16:58:44', NULL),
(47, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:49', '2025-12-02 16:58:49', NULL),
(48, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:58:55', '2025-12-02 16:58:55', NULL),
(49, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:59:00', '2025-12-02 16:59:00', NULL),
(50, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:59:06', '2025-12-02 16:59:06', NULL),
(51, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:59:12', '2025-12-02 16:59:12', NULL),
(52, 31, '{\"Cantidad\":\"4\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:59:18', '2025-12-02 16:59:18', NULL),
(53, 31, '{\"Cantidad\":\"2 - 2\",\"CLV\":\"122\",\"Linea\":\"SLIMPOP\",\"Area\":\"TI\",\"Departamento. Nombre\\/Posicion\":\"TI DANIELA\",\"Ubicacion\":\"BUNKER\",\"Estado\":\"NUEVO\",\"Hostname\":\"...\",\"Tipo_Computadora\":\"ESCRITORIO \",\"Marca\":\"HP\",\"Modelo\":\"ELITEBOOK\",\"Etiqueta\":\"12\",\"Express Code\":\"12\",\"Procesador\":\"RYZEN 7 \",\"Generacion\":\"7MA\",\"Nucleos\":\"8\",\"Memoria\":\"16GB\",\"Tipo_disco\":\"NVME 2.0\",\"Almacenamiento\":\"1 TB\",\"Sistema Operativo\":\"WINDOWS 11 PRO\",\"Cargador\":\"12\",\"IPv4\\/v6\":\"192.1.1.1\",\"Observaciones\":\"EL EQUIPO ESTA EN BUEN ESTADO \"}', '2025-12-02 16:59:22', '2025-12-03 16:34:02', NULL),
(54, 30, '{\"Cantidad\":\"1\",\"Codigo\":\"Cheko24150186\",\"Descripcion\":\"Scanner CHECKO2B\"}', '2025-12-03 17:03:51', '2025-12-03 17:03:51', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros_escaneos`
--

CREATE TABLE `registros_escaneos` (
  `id_escaneado` int(11) NOT NULL,
  `codigo_barras_producto` varchar(20) DEFAULT NULL,
  `descripcion_producto` varchar(255) DEFAULT NULL,
  `lote_escaneado` varchar(50) DEFAULT NULL,
  `fecha_escaneo` date DEFAULT NULL,
  `hora_escaneo` time DEFAULT NULL,
  `estado_escaneo` varchar(45) DEFAULT NULL,
  `nombre_colaborador_usuarios` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `registros_escaneos`
--

INSERT INTO `registros_escaneos` (`id_escaneado`, `codigo_barras_producto`, `descripcion_producto`, `lote_escaneado`, `fecha_escaneo`, `hora_escaneo`, `estado_escaneo`, `nombre_colaborador_usuarios`) VALUES
(1, '5154548465454', 'No encontrado', '31525TA1', '2025-11-11', '18:38:18', 'Fallido', 'Daniela (Administrador)'),
(2, '7503036787165', 'Cheddar & Caramel Mix', '31525TA1', '2025-11-11', '18:38:30', 'Exitoso', 'Daniela (Administrador)'),
(3, '1516514516544', 'No encontrado', '31525TA1', '2025-11-11', '18:39:00', 'Fallido', 'Daniela (Administrador)'),
(4, '7503036787165', 'Cheddar & Caramel Mix', '31525TA1', '2025-11-11', '18:39:12', 'Exitoso', 'Daniela (Administrador)'),
(5, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '18:44:47', 'Exitoso', 'Omar (Administrador)'),
(6, '750046397091', 'No encontrado', '31525TA1', '2025-11-11', '18:44:51', 'Fallido', 'Omar (Administrador)'),
(7, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:36', 'Exitoso', 'Daniela (Administrador)'),
(8, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:36', 'Exitoso', 'Omar (Administrador)'),
(9, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:39', 'Exitoso', 'Daniela (Administrador)'),
(10, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:40', 'Exitoso', 'Omar (Administrador)'),
(11, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:42', 'Exitoso', 'Omar (Administrador)'),
(12, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:44', 'Exitoso', 'Omar (Administrador)'),
(13, '5147858585858', 'No encontrado', '31525TA1', '2025-11-11', '20:40:44', 'Fallido', 'Daniela (Administrador)'),
(14, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:45', 'Exitoso', 'Omar (Administrador)'),
(15, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:47', 'Exitoso', 'Omar (Administrador)'),
(16, '7503036787140', 'No encontrado', '31525TA1', '2025-11-11', '20:40:47', 'Fallido', 'Daniela (Administrador)'),
(17, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:48', 'Exitoso', 'Omar (Administrador)'),
(18, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:51', 'Exitoso', 'Omar (Administrador)'),
(19, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:52', 'Exitoso', 'Daniela (Administrador)'),
(20, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:52', 'Exitoso', 'Omar (Administrador)'),
(21, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:53', 'Exitoso', 'Daniela (Administrador)'),
(22, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:55', 'Exitoso', 'Daniela (Administrador)'),
(23, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:55', 'Exitoso', 'Omar (Administrador)'),
(24, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:57', 'Exitoso', 'Daniela (Administrador)'),
(25, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:40:58', 'Exitoso', 'Omar (Administrador)'),
(26, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:40:58', 'Exitoso', 'Daniela (Administrador)'),
(27, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:41:00', 'Exitoso', 'Daniela (Administrador)'),
(28, 'a', 'No encontrado', '31525TA1', '2025-11-11', '20:41:00', 'Fallido', 'Omar (Administrador)'),
(29, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:03', 'Exitoso', 'Omar (Administrador)'),
(30, '7503036787148', 'No encontrado', '31525TA1', '2025-11-11', '20:41:05', 'Fallido', 'Daniela (Administrador)'),
(31, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:06', 'Exitoso', 'Omar (Administrador)'),
(32, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:08', 'Exitoso', 'Omar (Administrador)'),
(33, '7503036787147', 'No encontrado', '31525TA1', '2025-11-11', '20:41:09', 'Fallido', 'Daniela (Administrador)'),
(34, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:11', 'Exitoso', 'Omar (Administrador)'),
(35, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:41:12', 'Exitoso', 'Daniela (Administrador)'),
(36, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:12', 'Exitoso', 'Omar (Administrador)'),
(37, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:13', 'Exitoso', 'Omar (Administrador)'),
(38, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:41:13', 'Exitoso', 'Daniela (Administrador)'),
(39, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:15', 'Exitoso', 'Omar (Administrador)'),
(40, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31525TA1', '2025-11-11', '20:41:17', 'Exitoso', 'Daniela (Administrador)'),
(41, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:17', 'Exitoso', 'Omar (Administrador)'),
(42, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:19', 'Exitoso', 'Omar (Administrador)'),
(43, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:20', 'Exitoso', 'Omar (Administrador)'),
(44, '7503036787144', 'No encontrado', '31525TA1', '2025-11-11', '20:41:21', 'Fallido', 'Daniela (Administrador)'),
(45, '7500463970917', 'Slimpop Sweet & Salty 125g', '31525TA1', '2025-11-11', '20:41:22', 'Exitoso', 'Omar (Administrador)'),
(46, '7503036787146', 'No encontrado', '31525TA1', '2025-11-11', '20:41:25', 'Fallido', 'Daniela (Administrador)'),
(47, '1234567891011', 'Slimpop', '31525TA1', '2025-11-11', '21:32:15', 'Exitoso', 'Omar (Administrador)'),
(48, 'dads', 'No encontrado', '31625TA1', '2025-11-12', '17:13:32', 'Fallido', 'Omar (Administrador)'),
(49, 'f', 'No encontrado', '31625TA1', '2025-11-12', '20:30:06', 'Fallido', 'Omar (Administrador)'),
(50, '5566767667786', 'No encontrado', '31625TA1', '2025-11-13', '00:41:15', 'Fallido', 'Daniela (Administrador)'),
(51, 'gfgdgd', 'No encontrado', '31825TA1', '2025-11-15', '01:31:42', 'Fallido', 'Omar (Administrador)'),
(52, '345453454', 'No encontrado', 'Recepcion', '2025-11-18', '21:49:10', 'Fallido', 'Recepcion (Supervisor)'),
(53, 'kjhkjhkjh', 'No encontrado', 'Recepcion', '2025-11-18', '21:49:13', 'Fallido', 'Recepcion (Supervisor)'),
(54, '1515', 'No encontrado', 'Recepcion', '2025-11-19', '16:22:25', 'Fallido', 'Recepcion (Supervisor)'),
(55, '1222222222222', 'No encontrado', '32325TA1', '2025-11-19', '17:34:33', 'Fallido', 'Operador (Operador)'),
(56, '1222222222222', 'No encontrado', '32325TA1', '2025-11-19', '17:34:47', 'Fallido', 'Operador (Operador)'),
(57, '1212121224545', 'No encontrado', '32325TA1', '2025-11-19', '21:36:10', 'Fallido', 'Daniela (Administrador)'),
(58, '7548245725485', 'No encontrado', '32425TA1', '2025-11-20', '16:47:28', 'Fallido', 'Daniela (Administrador)'),
(59, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '32425TA1', '2025-11-20', '16:47:35', 'Exitoso', 'Daniela (Administrador)'),
(60, '7503036787147', 'No encontrado', '32425TA1', '2025-11-20', '16:47:41', 'Fallido', 'Daniela (Administrador)'),
(61, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '32425TA1', '2025-11-20', '16:47:45', 'Exitoso', 'Daniela (Administrador)'),
(62, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', 'Recepcion', '2025-11-20', '18:22:30', 'Exitoso', 'Recepcion (Supervisor)'),
(63, '1234567891011', 'Slimpop', '33225TA4', '2025-11-28', '23:25:34', 'Fallido', 'Daniela (Administrador)'),
(64, '4561846555521', 'No encontrado', '33225TA4', '2025-11-28', '23:26:08', 'Fallido', 'Daniela (Administrador)'),
(65, '1234567891011', 'Slimpop', '33225TA1', '2025-11-28', '23:27:25', 'Exitoso', 'Daniela (Administrador)'),
(66, '4514651465141', 'No encontrado', '33625TA1', '2025-12-02', '18:31:37', 'Fallido', 'Daniel (Supervisor)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `no_colaborador` int(11) NOT NULL,
  `nombre_colaborador` varchar(45) NOT NULL,
  `rol_colaborador` varchar(15) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `contrasena` varchar(15) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `estatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`no_colaborador`, `nombre_colaborador`, `rol_colaborador`, `area`, `contrasena`, `fecha`, `estatus`) VALUES
(9, 'JUAN', 'Operador', 'Cal', '12345678', '2025-11-21', 'Activo'),
(12, 'Operador', 'Operador', 'Cal', '12345678', '2025-11-06', 'Activo'),
(115, 'Recepcion', 'Supervisor', 'Recepcion', '12345678', '2025-11-18', 'Activo'),
(117, 'Alejandro Becerril', 'Administrador', 'TI', '12345678', '2025-11-06', 'Activo'),
(500, 'Daniel', 'Supervisor', 'Cal', '12345678', '2025-11-06', 'Activo'),
(501, 'Ricardo Alfonso Escamilla Morales', 'Administrador', 'TI', '12345678', '2025-11-18', 'Activo'),
(502, 'Sarahi', 'Supervisor', 'TH', '12345678', '2025-11-19', 'Activo'),
(512, 'Miguel', 'Supervisor', 'Mant', '12345678', '2025-11-19', 'Activo'),
(519, 'Rosendo', 'Supervisor', 'Almac', '12345678', '2025-11-19', 'Activo'),
(540, 'Erick', 'Supervisor', 'TI', '12345678', '2025-11-11', 'Activo'),
(580, 'Daniela', 'Administrador', 'TI', 'Buycraf7', '2025-10-16', 'Activo'),
(581, 'Omar', 'Administrador', 'TI', 'Buycraf7', '2025-11-06', 'Activo'),
(876, 'kk', 'Operador', 'Cal', '12345678', '2025-11-20', 'Activo'),
(888, 'Dani', 'Supervisor', 'Cal', '12345678', '2025-11-28', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `campos`
--
ALTER TABLE `campos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_campos_categoria` (`id_categoria`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inventario` (`inventario_id`);

--
-- Indices de la tabla `historial`
--
ALTER TABLE `historial`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_codigo_retiro` (`codigo_retiro`),
  ADD KEY `idx_operacion` (`operacion`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventario_areas`
--
ALTER TABLE `inventario_areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_inv_area` (`id_inventario`,`area_code`);

--
-- Indices de la tabla `inventario_categories_assoc`
--
ALTER TABLE `inventario_categories_assoc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_inv_cat` (`id_inventario`,`id_categoria`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `productos_escanear`
--
ALTER TABLE `productos_escanear`
  ADD PRIMARY KEY (`codigo_barras`),
  ADD UNIQUE KEY `descripcion` (`descripcion`);

--
-- Indices de la tabla `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categoria` (`categoria_id`);

--
-- Indices de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  ADD PRIMARY KEY (`id_escaneado`),
  ADD KEY `fk_codigo_barras` (`codigo_barras_producto`),
  ADD KEY `fk_descripcion` (`descripcion_producto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`no_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_2` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_3` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_4` (`nombre_colaborador`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `campos`
--
ALTER TABLE `campos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `historial`
--
ALTER TABLE `historial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `inventario_areas`
--
ALTER TABLE `inventario_areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inventario_categories_assoc`
--
ALTER TABLE `inventario_categories_assoc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `registros`
--
ALTER TABLE `registros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  MODIFY `id_escaneado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `campos`
--
ALTER TABLE `campos`
  ADD CONSTRAINT `fk_campos_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `fk_categorias_inventario` FOREIGN KEY (`inventario_id`) REFERENCES `inventarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `inventario_areas`
--
ALTER TABLE `inventario_areas`
  ADD CONSTRAINT `inventario_areas_ibfk_1` FOREIGN KEY (`id_inventario`) REFERENCES `inventarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `inventario_categories_assoc`
--
ALTER TABLE `inventario_categories_assoc`
  ADD CONSTRAINT `inventario_categories_assoc_ibfk_1` FOREIGN KEY (`id_inventario`) REFERENCES `inventarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventario_categories_assoc_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `registros`
--
ALTER TABLE `registros`
  ADD CONSTRAINT `fk_registros_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
