-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 10.200.10.213
-- Tiempo de generación: 23-10-2025 a las 00:58:40
-- Versión del servidor: 10.11.13-MariaDB-deb11-log
-- Versión de PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `popcode`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_inventario` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id_inventario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto_inventario` varchar(50) NOT NULL,
  `id_subcategoria` int(11) DEFAULT NULL,
  `descripcion` varchar(255) NOT NULL,
  `area` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `ubicacion` varchar(250) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `fecha_introduccion` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `no_serie` varchar(50) DEFAULT NULL,
  `necesidad` text DEFAULT NULL,
  `linea_equipo` varchar(50) DEFAULT NULL,
  `departamento_equipo` varchar(50) DEFAULT NULL,
  `nombre_posicion_equipo` varchar(100) DEFAULT NULL,
  `hostname_equipo` varchar(100) DEFAULT NULL,
  `tipo_computadora_equipo` varchar(100) DEFAULT NULL,
  `etiqueta_servicio_equipo` varchar(100) DEFAULT NULL,
  `express_code_equipo` varchar(100) DEFAULT NULL,
  `procesador_equipo` varchar(100) DEFAULT NULL,
  `generacion_equipo` varchar(50) DEFAULT NULL,
  `nucleos` varchar(20) DEFAULT NULL,
  `memoria_equipo` varchar(50) DEFAULT NULL,
  `tipo_disco` varchar(45) DEFAULT NULL,
  `almacenamiento_equipo` varchar(50) DEFAULT NULL,
  `sistema_operativo_equipo` varchar(100) DEFAULT NULL,
  `cargador_equipo` varchar(50) DEFAULT NULL,
  `IPv4_v6_equipo` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `adicional` text DEFAULT NULL,
  `especificaciones` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_escanear`
--

CREATE TABLE `productos_escanear` (
  `codigo_barras` varchar(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros_escaneos`
--

CREATE TABLE `registros_escaneos` (
  `id_escaneado` int(11) NOT NULL,
  `codigo_barras_producto` varchar(20) DEFAULT NULL,
  `descripcion_producto` varchar(255) DEFAULT NULL,
  `lote_escaneado` int(11) DEFAULT NULL,
  `fecha_escaneo` date DEFAULT NULL,
  `hora_escaneo` time DEFAULT NULL,
  `estado_escaneo` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `retiros`
--

CREATE TABLE `retiros` (
  `codigo_retiro` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `operacion` varchar(50) DEFAULT NULL,
  `no_colaborador_retiro` varchar(15) DEFAULT NULL,
  `inventario_retiro` int(11) DEFAULT NULL,
  `categoria_retiro` int(11) DEFAULT NULL,
  `subcategoria_retiro` int(11) DEFAULT NULL,
  `descripcion_retiro` varchar(255) NOT NULL,
  `cantidad_retiro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcategorias`
--

CREATE TABLE `subcategorias` (
  `id_subcategoria` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `no_colaborador` varchar(15) NOT NULL,
  `nombre_colaborador` varchar(45) NOT NULL,
  `rol_colaborador` varchar(15) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `contrasena` varchar(15) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `estatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`no_colaborador`, `nombre_colaborador`, `rol_colaborador`, `area`, `contrasena`, `fecha`, `estatus`) VALUES
('DELTA 580', 'Daniela', 'Administrador', 'TI', 'Buycraf7', '2025-10-16', 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`),
  ADD KEY `id_inventario` (`id_inventario`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id_inventario`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto_inventario`),
  ADD UNIQUE KEY `descripcion_unica` (`descripcion`),
  ADD KEY `fk_id_subcategoria` (`id_subcategoria`);

--
-- Indices de la tabla `productos_escanear`
--
ALTER TABLE `productos_escanear`
  ADD PRIMARY KEY (`codigo_barras`),
  ADD UNIQUE KEY `descripcion` (`descripcion`);

--
-- Indices de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  ADD PRIMARY KEY (`id_escaneado`),
  ADD KEY `fk_codigo_barras` (`codigo_barras_producto`),
  ADD KEY `fk_descripcion` (`descripcion_producto`);

--
-- Indices de la tabla `retiros`
--
ALTER TABLE `retiros`
  ADD PRIMARY KEY (`codigo_retiro`),
  ADD KEY `fk_no_colaborador` (`no_colaborador_retiro`),
  ADD KEY `fk_inventario` (`inventario_retiro`),
  ADD KEY `fk_categoria` (`categoria_retiro`),
  ADD KEY `fk_subcategoria` (`subcategoria_retiro`),
  ADD KEY `fk_descripcion_producto` (`descripcion_retiro`);

--
-- Indices de la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  ADD PRIMARY KEY (`id_subcategoria`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`no_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_2` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_3` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_4` (`nombre_colaborador`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id_inventario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  MODIFY `id_escaneado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `retiros`
--
ALTER TABLE `retiros`
  MODIFY `codigo_retiro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  MODIFY `id_subcategoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `categorias_ibfk_1` FOREIGN KEY (`id_inventario`) REFERENCES `inventarios` (`id_inventario`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_id_subcategoria` FOREIGN KEY (`id_subcategoria`) REFERENCES `subcategorias` (`id_subcategoria`);

--
-- Filtros para la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  ADD CONSTRAINT `fk_codigo_barras` FOREIGN KEY (`codigo_barras_producto`) REFERENCES `productos_escanear` (`codigo_barras`),
  ADD CONSTRAINT `fk_descripcion` FOREIGN KEY (`descripcion_producto`) REFERENCES `productos_escanear` (`descripcion`);

--
-- Filtros para la tabla `retiros`
--
ALTER TABLE `retiros`
  ADD CONSTRAINT `fk_categoria` FOREIGN KEY (`categoria_retiro`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `fk_descripcion_producto` FOREIGN KEY (`descripcion_retiro`) REFERENCES `productos` (`descripcion`),
  ADD CONSTRAINT `fk_inventario` FOREIGN KEY (`inventario_retiro`) REFERENCES `inventarios` (`id_inventario`),
  ADD CONSTRAINT `fk_no_colaborador` FOREIGN KEY (`no_colaborador_retiro`) REFERENCES `usuarios` (`no_colaborador`),
  ADD CONSTRAINT `fk_subcategoria` FOREIGN KEY (`subcategoria_retiro`) REFERENCES `subcategorias` (`id_subcategoria`);

--
-- Filtros para la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  ADD CONSTRAINT `subcategorias_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
