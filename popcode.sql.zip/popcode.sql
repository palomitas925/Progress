-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 10.200.10.213
-- Tiempo de generación: 11-11-2025 a las 00:08:35
-- Versión del servidor: 10.11.13-MariaDB-deb11-log
-- Versión de PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `popcode`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `campos`
--

CREATE TABLE `campos` (
  `id` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `tipo` varchar(50) DEFAULT 'text',
  `orden` int(11) DEFAULT 0,
  `requerido` tinyint(1) DEFAULT 0,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `inventario_id` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `campos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[]' CHECK (json_valid(`campos`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `identificador` varchar(100) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_escanear`
--

CREATE TABLE `productos_escanear` (
  `codigo_barras` varchar(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `productos_escanear`
--

INSERT INTO `productos_escanear` (`codigo_barras`, `descripcion`, `imagen`, `fecha`) VALUES
('123456789', 'Prueba', '690b96e8a4196_Secuencia del sistema.jpg', '2025-10-30'),
('1234567891011', 'Slimpop', '690cc69befa1e_error.png', '2025-10-31'),
('2537492563524', 'Prueba2', 'prod_2537492563524_1761935744.png', '2025-10-31'),
('45245654678467867', 'BorraR', '69039859b198b_REGESC.png', '2025-10-30'),
('7500463970917', 'Slimpop Sweet & Salty 125g', '1761763539_Sweet.png', '2025-10-23'),
('7503036785103', 'Slimpop Netflix Sabor Salsas Negras 125g', 'prod_7503036785103_1761251383.jpg', '2025-10-23'),
('7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', 'prod_7503036787141_1761251357.jpg', '2025-10-23'),
('7503036787158', 'Netflix Mantequilla', '6903b589c589e_prueba 3.jpg', '2025-10-30'),
('7503036787165', 'Cheddar & Caramel Mix', 'prod_7503036787165_1762370246.png', '2025-11-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE `registros` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `datos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`datos`)),
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `texto_busqueda` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros_escaneos`
--

CREATE TABLE `registros_escaneos` (
  `id_escaneado` int(11) NOT NULL,
  `codigo_barras_producto` varchar(20) DEFAULT NULL,
  `descripcion_producto` varchar(255) DEFAULT NULL,
  `lote_escaneado` varchar(50) DEFAULT NULL,
  `fecha_escaneo` date DEFAULT NULL,
  `hora_escaneo` time DEFAULT NULL,
  `estado_escaneo` varchar(45) DEFAULT NULL,
  `nombre_colaborador_usuarios` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `registros_escaneos`
--

INSERT INTO `registros_escaneos` (`id_escaneado`, `codigo_barras_producto`, `descripcion_producto`, `lote_escaneado`, `fecha_escaneo`, `hora_escaneo`, `estado_escaneo`, `nombre_colaborador_usuarios`) VALUES
(1, '7503036787165', 'Cheddar & Caramel Mix', '31025TA1', '2025-11-06', '23:30:15', 'Exitoso', 'Omar (Administrador)'),
(2, '45554541', 'No encontrado', '31025TA1', '2025-11-06', '23:30:32', 'Fallido', 'Omar (Administrador)'),
(3, '4165455478664', 'No encontrado', '31025TA1', '2025-11-06', '23:31:47', 'Fallido', 'Daniela (Administrador)'),
(4, '{kSPBsHq', 'No encontrado', '31025TA1', '2025-11-06', '23:32:12', 'Fallido', 'Daniela (Administrador)'),
(5, '2518747845125', 'No encontrado', '31025TA1', '2025-11-06', '23:38:47', 'Fallido', 'Daniela (Administrador)'),
(6, '7503036787169', 'No encontrado', '31125TA1', '2025-11-07', '16:41:22', 'Fallido', 'Daniela (Administrador)'),
(7, '7503036787165', 'Cheddar & Caramel Mix', '31125TA1', '2025-11-07', '16:41:28', 'Exitoso', 'Daniela (Administrador)'),
(8, '7503036787165', 'Cheddar & Caramel Mix', '31125TA1', '2025-11-07', '16:41:31', 'Exitoso', 'Daniela (Administrador)'),
(9, '7503036787165', 'Cheddar & Caramel Mix', '31125TA1', '2025-11-07', '16:41:33', 'Exitoso', 'Daniela (Administrador)'),
(10, '1544444444444', 'No encontrado', '31125TA1', '2025-11-07', '16:51:59', 'Fallido', 'Daniela (Administrador)'),
(11, '2652135215656', 'No encontrado', '31125TA1', '2025-11-07', '17:08:57', 'Fallido', 'Daniela (Administrador)'),
(12, '1444444444444', 'No encontrado', '31125TA1', '2025-11-07', '17:09:19', 'Fallido', 'Daniela (Administrador)'),
(13, '7503036787165', 'Cheddar & Caramel Mix', '31125TA1', '2025-11-07', '17:09:34', 'Exitoso', 'Daniela (Administrador)'),
(14, '6555555555555', 'No encontrado', '31125TA1', '2025-11-07', '17:12:54', 'Fallido', 'Daniela (Administrador)'),
(15, '5215645454654', 'No encontrado', '31425TA1', '2025-11-10', '21:02:18', 'Fallido', 'Daniela (Administrador)'),
(16, '2165155646541', 'No encontrado', '31425TA1', '2025-11-10', '21:02:26', 'Fallido', 'Daniela (Administrador)'),
(17, '7503036787165', 'Cheddar & Caramel Mix', '31425TA1', '2025-11-10', '21:03:21', 'Exitoso', 'Daniela (Administrador)'),
(18, '7503036787165', 'Cheddar & Caramel Mix', '31425TA1', '2025-11-10', '21:03:26', 'Exitoso', 'Daniela (Administrador)'),
(19, '7503036787165', 'Cheddar & Caramel Mix', '31425TA1', '2025-11-10', '21:25:12', 'Exitoso', 'Daniela (Administrador)'),
(20, '5444654658852', 'No encontrado', '31425TA1', '2025-11-10', '23:32:06', 'Fallido', 'Daniela (Administrador)'),
(21, '1445454688754', 'No encontrado', '31425TA1', '2025-11-10', '23:32:10', 'Fallido', 'Daniela (Administrador)'),
(22, '5555546544874', 'No encontrado', '31425TA1', '2025-11-10', '23:32:16', 'Fallido', 'Daniela (Administrador)'),
(23, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31425TA1', '2025-11-10', '23:33:10', 'Exitoso', 'Daniela (Administrador)'),
(24, '7503036787141', 'Slimpop Netflix Sabor a chamoy 140g', '31425TA1', '2025-11-10', '23:33:19', 'Exitoso', 'Daniela (Administrador)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `no_colaborador` int(11) NOT NULL,
  `nombre_colaborador` varchar(45) NOT NULL,
  `rol_colaborador` varchar(15) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `contrasena` varchar(15) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `estatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`no_colaborador`, `nombre_colaborador`, `rol_colaborador`, `area`, `contrasena`, `fecha`, `estatus`) VALUES
(1, 'Operador1', 'Operador', 'Cal', '12345678', '2025-11-06', 'Activo'),
(12, 'Operador', 'Operador', 'Cal', '12345678', '2025-11-06', 'Activo'),
(117, 'Giga', 'Administrador', 'TI', 'Buycraf7', '2025-11-06', 'Activo'),
(500, 'Daniel', 'Supervisor', 'Cal', '12345678', '2025-11-06', 'Activo'),
(580, 'Daniela', 'Administrador', 'TI', 'Buycraf7', '2025-10-16', 'Activo'),
(581, 'Omar', 'Administrador', 'TI', '12345678', '2025-11-06', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `campos`
--
ALTER TABLE `campos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_campos_categoria` (`id_categoria`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inventario` (`inventario_id`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos_escanear`
--
ALTER TABLE `productos_escanear`
  ADD PRIMARY KEY (`codigo_barras`),
  ADD UNIQUE KEY `descripcion` (`descripcion`);

--
-- Indices de la tabla `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categoria` (`categoria_id`);

--
-- Indices de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  ADD PRIMARY KEY (`id_escaneado`),
  ADD KEY `fk_codigo_barras` (`codigo_barras_producto`),
  ADD KEY `fk_descripcion` (`descripcion_producto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`no_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_2` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_3` (`nombre_colaborador`),
  ADD UNIQUE KEY `nombre_colaborador_4` (`nombre_colaborador`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `campos`
--
ALTER TABLE `campos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `registros`
--
ALTER TABLE `registros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `registros_escaneos`
--
ALTER TABLE `registros_escaneos`
  MODIFY `id_escaneado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `campos`
--
ALTER TABLE `campos`
  ADD CONSTRAINT `fk_campos_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `fk_categorias_inventario` FOREIGN KEY (`inventario_id`) REFERENCES `inventarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `registros`
--
ALTER TABLE `registros`
  ADD CONSTRAINT `fk_registros_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
