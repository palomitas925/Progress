<?php
session_start();
include 'conexion.php';
date_default_timezone_set('America/Mexico_City');

$usuario = $_SESSION['usuario'] ?? 'desconocido';
$mensaje = "";

// Obtener productos registrados
$productos = [];
$resultado = $conn->query("SELECT descripcion FROM productos_escanear ORDER BY descripcion ASC");
while ($row = $resultado->fetch_assoc()) {
  $productos[] = $row['descripcion'];
}

// Procesar escaneo
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $producto = $_POST['producto'];
  $lote = $_POST['lote'];
  $operador = $usuario;
  $estado = "exitoso";

  if ($producto && $lote) {
    $stmt = $conn->prepare("SELECT codigo_barras FROM productos_escanear WHERE descripcion = ?");
    $stmt->bind_param("s", $producto);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $codigo = $row['codigo_barras'];

      $insert = $conn->prepare("INSERT INTO registros_escaneos (
        codigo_barras_producto,
        descripcion_producto,
        lote_escaneado,
        fecha_escaneo,
        hora_escaneo,
        estado_escaneo,
        nombre_colaborador_usuarios
      ) VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, ?)");

      $insert->bind_param("isisss", $codigo, $producto, $lote, $estado, $operador);
      $insert->execute();
      $insert->close();

      $mensaje = "✅ Escaneo registrado correctamente.";
    } else {
      $mensaje = "❌ Producto no encontrado en la base de datos.";
    }

    $stmt->close();
  } else {
    $mensaje = "⚠️ Por favor completa todos los campos.";
  }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>POP CODE - Selección de Producto</title>
  <style>
    /* Tu estilo original intacto */
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #18bdff;
      color: #333;
    }

    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #ffffff;
      padding: 10px 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      position: relative;
    }

    header h1 {
      font-size: 24px;
      color: #0e96cc;
      margin: 0 auto;
    }

    main {
      padding: 30px;
      text-align: center;
    }

    .form-card {
      background-color: #fff;
      border-radius: 10px;
      padding: 50px;
      max-width: 600px;
      margin: 0 auto;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .form-card label {
      font-weight: bold;
      color: #0e96cc;
      text-align: left;
    }

    .form-card select,
    .form-card input {
      padding: 10px;
      border: 2px solid #0e96cc;
      border-radius: 8px;
      font-size: 16px;
    }

    .form-card input[readonly] {
      background-color: #f0f0f0;
      cursor: pointer;
    }

    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    .button-group button {
      flex: 1;
      margin: 0 5px;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      color: white;
      transition: background-color 0.3s ease;
    }

    .cancel-btn {
      background-color: #ce1f1f;
    }

    .cancel-btn:hover {
      background-color: #1b0909;
    }

    .continue-btn {
      background-color: #078dfa;
    }

    .continue-btn:hover {
      background-color: #28b33f;
    }

    .resultado {
      margin-top: 15px;
      font-weight: bold;
      color: green;
    }

    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: #fff;
      margin: 10% auto;
      padding: 20px;
      border-radius: 10px;
      width: 300px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .modal-content select {
      padding: 8px;
      border: 2px solid #0e96cc;
      border-radius: 8px;
      font-size: 14px;
    }

    .modal-content button {
      padding: 10px;
      border: none;
      border-radius: 8px;
      background-color: #0e96cc;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }

    .modal-content button:hover {
      background-color: #007bb5;
    }

    .logo-inferior {
      position: fixed;
      bottom: 10px;
      right: 10px;
      width: 80px;
      height: auto;
      z-index: 999;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <header>
    <h1>¿Qué producto desea escanear hoy?</h1>
  </header>

  <main>
    <form method="POST">
      <div class="form-card">
        <label for="producto">Producto a escanear:</label>
        <select id="producto" name="producto" required>
          <option value="">-- Selecciona --</option>
          <?php foreach ($productos as $descripcion): ?>
            <option value="<?= htmlspecialchars($descripcion) ?>"><?= htmlspecialchars($descripcion) ?></option>
          <?php endforeach; ?>
        </select>

        <label for="lote">No. Lote:</label>
        <input type="text" id="lote" name="lote" readonly placeholder="Haz clic para generar" onclick="abrirModal()">

        <label for="operador">Operador:</label>
        <input type="text" id="operador" value="<?= htmlspecialchars($usuario) ?>" readonly>

        <div class="button-group">
          <button class="cancel-btn" type="button" onclick="window.location.href='escaneo.html'">Cancelar</button>
          <button class="continue-btn" type="button" onclick="window.location.href='escaneo_producto.php'">Continuar</button>
         <!-- <button class="continue-btn" type="button" onclick="window.location.href='registro_escaneos.php'">Ver Registros</button> -->
        </div>

        <?php if (!empty($mensaje)): ?>
          <div class="resultado"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>
      </div>
    </form>
  </main>

  <!-- Modal -->
  <div class="modal" id="modal">
    <div class="modal-content">
      <label>Tipo de Producto:</label>
      <select id="modal-tipo">
        <option value="T">T</option>
        <option value="TP">TP</option>
      </select>

      <label>Turno:</label>
      <select id="modal-turno">
        <option value="A">Matutino (A)</option>
        <option value="B">Vespertino (B)</option>
        <option value="C">Nocturno (C)</option>
      </select>

      <label>Línea:</label>
      <select id="modal-linea">
        <option value="1">Línea 1</option>
        <option value="2">Línea 2</option>
        <option value="3">Línea 3</option>
      </select>

      <button onclick="generarLote()">Generar Lote</button>
    </div>
  </div>

  <img src="../imagenes/slimpop-blanca.png" alt="Logo inferior" class="logo-inferior">

  <script>
    function abrirModal() {
      document.getElementById("modal").style.display = "block";
    }

    function cerrarModal() {
      document.getElementById("modal").style.display = "none";
    }

    function getJulianDay() {
      const now = new Date();
      const start = new Date(now.getFullYear(), 0, 0);
      const diff = now - start;
      const oneDay = 1000 * 60 * 60 * 24;
      const day = Math.floor(diff / oneDay);
      return day.toString().padStart(3, '0');
    }

    function generarLote() {
      const tipo = document.getElementById("modal-tipo").value;
      const turno = document.getElementById("modal-turno").value;
      const linea = document.getElementById("modal-linea").value;

      if (!tipo || !turno || !linea) {
        alert("Por favor selecciona todos los campos.");
        return;
      }

      const juliano = getJulianDay();
      const año = new Date().getFullYear().toString().slice(-2);
      const lote = `${juliano}${año}${tipo}${turno}${linea}`.toUpperCase();

      document.getElementById("lote").value = lote;
      document.getElementById("modal").style.display = "none";
    }

    window.onclick = function (event) {
      const modal = document.getElementById("modal");
      if (event.target === modal) {
        cerrarModal();
      }
    }
  </script>
</body>
</html>
