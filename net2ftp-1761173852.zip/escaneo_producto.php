<?php
session_start();
include 'conexion.php';
date_default_timezone_set('America/Mexico_City');

$descripcion = "";
$imagen = "img/placeholder.png";
$estado = "";
$alerta = false;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['codigo_barras']) && isset($_POST['lote_escaneado'])) {
    $codigo = trim($_POST['codigo_barras']);
    $lote = trim($_POST['lote_escaneado']);
    $usuario = $_SESSION['usuario'] ?? 'desconocido';

    // Obtener descripción e imagen del producto escaneado
    $consulta = $conn->prepare("SELECT descripcion, imagen FROM productos_escanear WHERE codigo_barras = ?");
    $consulta->bind_param("s", $codigo);
    $consulta->execute();
    $resultado = $consulta->get_result();

    $estado = "fallido";
    if ($resultado->num_rows > 0) {
        $datos = $resultado->fetch_assoc();
        $descripcion = $datos['descripcion'];
        $imagen = "imagenes_productos/" . $datos['imagen'];
        $estado = "exitoso";

        // Registrar escaneo
        $registro = $conn->prepare("INSERT INTO registros_escaneos (
            codigo_barras_producto,
            descripcion_producto,
            lote_escaneado,
            fecha_escaneo,
            hora_escaneo,
            estado_escaneo,
            nombre_colaborador_usuarios
        ) VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, ?)");

        $registro->bind_param("isisss", $codigo, $descripcion, $lote, $estado, $usuario);
        $registro->execute();
    } else {
        $descripcion = "No encontrado";
        $imagen = "img/error.png";
        $alerta = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>POPCODE</title>
  <link rel="stylesheet" href="estilo_esc_prod.css">
</head>
<body>
  <?php if ($alerta): ?>
    <audio autoplay>
      <source src="sonidos/alerta.mp3" type="audio/mpeg">
    </audio>
  <?php endif; ?>

  <div class="contenedor">
    <div class="panel-izquierdo">
      <h1>Escaneo de Productos</h1>
      <form method="POST">
        <label>Código de barras:</label>
        <input type="text" name="codigo_barras" autofocus autocomplete="off" required>

        <label>Descripción:</label>
        <input type="text" value="<?= htmlspecialchars($descripcion) ?>" readonly>

        <label>Lote escaneado:</label>
        <input type="text" name="lote_escaneado" required>

        <div class="focos">
          <div class="foco <?= $estado === 'exitoso' ? 'verde' : ($estado === 'fallido' ? 'rojo' : '') ?>"></div>
        </div>

        <div class="botones">
          <button type="submit">Registrar Escaneo</button>
          <button type="button" onclick="location.href='producto_escanear_lote.php'">Regresar</button>
          <button type="button" onclick="location.href='registro_escaneos.php'">Registros</button>
        </div>
      </form>
    </div>

    <div class="panel-derecho">
      <label>Imagen:</label>
      <div class="imagen">
        <img src="<?= htmlspecialchars($imagen) ?>" alt="Imagen del producto" width="200">
        <p>IMG 600x900</p>
      </div>
    </div>
  </div>
</body>
</html>
